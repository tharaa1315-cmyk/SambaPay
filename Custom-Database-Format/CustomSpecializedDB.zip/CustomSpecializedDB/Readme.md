this custom database format is effecient and can serve many people at same time. and this is for future implementation
